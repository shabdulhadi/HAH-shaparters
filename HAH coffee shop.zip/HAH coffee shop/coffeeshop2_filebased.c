#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <windows.h>

#define MAX_USERS 100
#define MAX_ITEMS 100

// Global variables
char users[MAX_USERS][50];
char passwords[MAX_USERS][50];
char menuItems[MAX_ITEMS][50];

char usersOrderList[MAX_USERS][MAX_ITEMS][50];
int userOrderCounts[MAX_USERS] = {0};
int currentUserIndex = -1;
int selectedUserIndex = -1;

double itemPrices[MAX_ITEMS];

int stockQuantities[MAX_ITEMS];

int totalMenuItems = 0;
int totalUsers = 0;
char preferance[20];

char orderCustomers[MAX_USERS][50];
double orderPrices[MAX_USERS];
char orderItems[MAX_USERS][50];
int orderQuantities[MAX_USERS];
char orderPreferences[MAX_USERS][50];
int totalOrders = 0;
double totalBill = 0;
double discountvalue = 0.1;
char yesno[10];
char user[50], password[50];

// Function declarations
void Menu();
void signUp(const char *user, const char *password);
int signIn(const char *user, const char *password);
void validationsignin();
int isUserPresent(const char *user);
int isAdmin(const char *user, const char *password);
void isuser();
void editCustomer(int index);
void viewAllCustomers();
void userManagement();

void viewAllOrders();
void inventory();
void viewitems();
void additems();
void delitems();
void orders();
void printReceipt();
void discount();

//admin password==1234
//discount voucher ==1234


#define MAX_LINE_LENGTH 200
#define MAX_FIELD_LENGTH 50

void getField(const char *data, int field, char *output)
{
    int commaCount = 1;
    int outputIndex = 0;
    output[0] = '\0';

    for (int i = 0; data[i] != '\0'; i++)
    {
        if (data[i] == ',')
        {
            commaCount++;
            if (commaCount > field)
                break;
            outputIndex = 0;
            continue;
        }
        if (commaCount == field)
        {
            output[outputIndex++] = data[i];
            output[outputIndex] = '\0';
        }
    }
}

void loadUsersFromFile()
{
    FILE *file = fopen("users.txt", "r");
    if (!file)
        return;

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), file) && totalUsers < MAX_USERS)
    {
        line[strcspn(line, "\n")] = '\0';
        getField(line, 1, users[totalUsers]);
        getField(line, 2, passwords[totalUsers]);
        totalUsers++;
    }
    fclose(file);
}

void saveUsersToFile()
{
    FILE *file = fopen("users.txt", "w");
    if (!file)
        return;

    for (int i = 0; i < totalUsers; i++)
    {
        fprintf(file, "%s,%s\n", users[i], passwords[i]);
    }
    fclose(file);
}

void loadMenuFromFile()
{
    FILE *file = fopen("menu.txt", "r");
    if (!file)
        return;

    char line[MAX_LINE_LENGTH];
    char temp[MAX_FIELD_LENGTH];

    while (fgets(line, sizeof(line), file) && totalMenuItems < MAX_ITEMS)
    {
        line[strcspn(line, "\n")] = '\0';
        getField(line, 1, menuItems[totalMenuItems]);
        getField(line, 2, temp);
        itemPrices[totalMenuItems] = atof(temp);
        getField(line, 3, temp);
        stockQuantities[totalMenuItems] = atoi(temp);
        totalMenuItems++;
    }
    fclose(file);
}

void saveMenuToFile()
{
    FILE *file = fopen("menu.txt", "w");
    if (!file)
        return;

    for (int i = 0; i < totalMenuItems; i++)
    {
        fprintf(file, "%s,%.2f,%d\n", menuItems[i], itemPrices[i], stockQuantities[i]);
    }
    fclose(file);
}

void saveOrdersToFile()
{
    FILE *file = fopen("orders.txt", "w");
    if (!file)
        return;

    for (int i = 0; i < totalUsers; i++)
    {
        if (userOrderCounts[i] == 0)
            continue;
        fprintf(file, "%s,%d", users[i], userOrderCounts[i]);
        for (int j = 0; j < userOrderCounts[i]; j++)
        {
            fprintf(file, ",%s", usersOrderList[i][j]);
        }
        fprintf(file, "\n");
    }
    fclose(file);
}

// Main function
int main()
{
    loadUsersFromFile();
    loadMenuFromFile();
    printf("=============================================\n");
    printf("   Welcome to the Sign In/Sign Up page!\n");
    printf("=============================================\n");

    int choice;
    do
    {
        Menu();
        scanf("%d", &choice);
        getchar(); // consume newline

        switch (choice)
        {
        case 1:
            system("cls");
            printf("=====================\n");
            printf("      SIGN UP\n");
            printf("=====================\n");
            printf("Enter your username: ");
            scanf(" %[^\n]s", user);
            printf("Enter your password: ");
            scanf(" %[^\n]s", password);

            if (strcmp(user, "admin") == 0 || isUserPresent(user))
            {
                printf("User already exists\n");
                break;
            }
            else
            {
                signUp(user, password);
            }
            break;

        case 2:
            validationsignin();
            choice = 3; // Exit after sign-in
            break;

        case 3:
            printf("Exiting...\n");
            break;

        default:
            printf("Invalid choice\n");
        }
        getch();
        system("cls");
    } while (choice != 3);

    saveUsersToFile();
    saveMenuToFile();
    saveOrdersToFile();
    return 0;
}
// User registration functions
void signUp(const char *newUser, const char *newPassword)
{
    strcpy(users[totalUsers], newUser);
    strcpy(passwords[totalUsers], newPassword);
    totalUsers++;
    printf("====================================\n");
    printf("   Sign up successful!\n");
    saveUsersToFile();
    printf("====================================\n");
}

int signIn(const char *username, const char *pwd)
{
    if (isAdmin(username, pwd))
    {
        return 1;
    }

    for (int i = 0; i < totalUsers; i++)
    {
        if (strcmp(users[i], username) == 0)
        {
            if (strcmp(passwords[i], pwd) == 0)
            {
                currentUserIndex = i;
                printf("====================================\n");
                printf("   Welcome %s\n", users[i]);
                printf("====================================\n");
                isuser();
                return 1;
            }
        }
    }
    printf("Invalid user or password\n");
    validationsignin();
    saveUsersToFile();
    saveMenuToFile();
    saveOrdersToFile();
    return 0;
}

int isUserPresent(const char *checkUser)
{
    for (int i = 0; i < totalUsers; i++)
    {
        if (strcmp(users[i], checkUser) == 0)
        {
            return 1;
        }
    }
    saveUsersToFile();
    saveMenuToFile();
    saveOrdersToFile();
    return 0;
}

void Menu()
{
    printf("=============================================\n");
    printf("     Welcome To HAH coffee shop\n");
    printf("=============================================\n");
    printf("Sign up if you are a new user OR Sign in (Existing user/Admin)\n");
    printf("-------------------------------------------------------------\n");
    printf("1. Sign Up\n");
    printf("2. Sign In\n");
    printf("3. Exit\n");
    printf("-------------------------------------------------------------\n");
    printf("Enter your choice: ");
}

// Admin check function
int isAdmin(const char *email, const char *pwd)
{
    if (strcmp(email, "admin") == 0 && strcmp(pwd, "1234") == 0)
    {
    admin_menu:
        int choice;
        system("cls");
        printf("====================================\n");
        printf("       Welcome Admin :))\n");
        printf("====================================\n");
        printf("1. USER MANAGEMENT\n");
        printf("2. VIEW ALL ORDERS\n");
        printf("3. INVENTORY MANAGEMENT\n");
        printf("4. DISCOUNTS AND OFFERS MANAGEMENT\n");
        printf("5. EXIT TO MAIN MENU\n");
        printf("-------------------------------------------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // consume newline

        switch (choice)
        {
        case 1:
            system("cls");
            userManagement();
            break;
        case 2:
            system("cls");
            viewAllOrders();
            break;
        case 3:
            system("cls");
            inventory();
            break;
        case 4:
            system("cls");
            discount();
            getch();
            system("cls");
            goto admin_menu;
        case 5:
             system("cls");
             main();
            system("cls");
            saveUsersToFile();
            saveMenuToFile();
            saveOrdersToFile();
            return 0;
        default:
            system("cls");
            printf("\nInvalid choice! Please Re-Enter\n");
            goto admin_menu;
        }
        return 1;
    }
    else
    {
        saveUsersToFile();
        saveMenuToFile();
        saveOrdersToFile();
        return 0;
    }
}
void isuser()
{
    int choice = 0;
    char suggest[100];

    do
    {
        system("cls");
        printf("====================================\n");
        printf("        User Interface\n");
        printf("====================================\n");
        printf("1. View menu\n");
        printf("2. Place order\n");
        printf("3. Give any suggestions\n");
        printf("4. Sign out\n");
        printf("-------------------------------------------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // consume newline

        switch (choice)
        {
        case 1:
            system("cls");
            printf("====================================\n");
            printf("        Total Menu Items\n");
            printf("====================================\n");
            printf("====================================\n");
            printf("            MENU\n");
            printf("====================================\n");
            for (int i = 0; i < totalMenuItems; i++)
            {
                printf("%d. %s - $%.2f\n", i + 1, menuItems[i], itemPrices[i]);
            }
            printf("Press any key to continue...\n");
            getch();
            break;

        case 2:
            system("cls");
            orders();
            break;

        case 3:
            system("cls");
            printf("Enter your suggestion: ");
            scanf(" %[^\n]s", suggest);
            printf("Thank you for your suggestion!\n");
            printf("Press any key to continue...\n");
            getch();
            break;

        case 4:
            printf("Signing out...\n");
            getch();
            system("cls");
            main();
            break;

        default:
            printf("Invalid choice! Please try again.\n");
            getch();
            break;
        }
    } while (choice != 4);
}

void userManagement()
{
    int option;

    do
    {
        system("cls");
        printf("====================================\n");
        printf("      USER MANAGEMENT MENU\n");
        printf("====================================\n");
        printf("1. View All Customers\n");
        printf("2. Edit Customer Details\n");
        printf("3. Exit\n");
        printf("-------------------------------------------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &option);
        getchar(); // consume newline

        switch (option)
        {
        case 1:
            system("cls");
            viewAllCustomers();
            printf("Press any key to continue...");
            getch();
            break;
        case 2:
            system("cls");
            viewAllCustomers();
            printf("\nEnter customer number (1-%d): ", totalUsers);
            scanf("%d", &selectedUserIndex);
            getchar();

            if (selectedUserIndex >= 1 && selectedUserIndex <= totalUsers)
            {
                system("cls");
                editCustomer(selectedUserIndex - 1);
            }
            else
            {
                printf("Invalid user number!\n");
                getch();
            }
            break;
        case 3:
            printf("Exiting User Management...\n");
            getch();
            system("cls");
            isAdmin(user, password);
            break;
        default:
            printf("Invalid choice. Please try again.\n");
            getch();
        }
    } while (option != 3);
}

void viewAllCustomers()
{
    printf("====================================\n");
    printf("          User List\n");
    printf("====================================\n");
    for (int i = 0; i < totalUsers; i++)
    {
        printf("%d. %s\n", i + 1, users[i]);
    }
    printf("====================================\n");
}

void editCustomer(int index)
{
    printf("Editing customer: %s\n", users[index]);
    printf("Enter new email: ");
    scanf(" %[^\n]s", users[index]);
    printf("====================================\n");
    printf("Customer details updated successfully!\n");
    printf("====================================\n");
    printf("Press any key to continue...");
    getch();
}

void viewAllOrders()
{
    printf("============================================================\n");
    printf("                   ALL CUSTOMER ORDERS\n");
    printf("============================================================\n");

    int ordersExist = 0;

    for (int i = 0; i < totalUsers; i++)
    {
        if (userOrderCounts[i] > 0)
        {
            ordersExist = 1;
            printf("\nCustomer: %s\n", users[i]);
            printf("------------------------------------------------------------\n");

            for (int j = 0; j < userOrderCounts[i]; j++)
            {
                printf("Order %d: %s\n", j + 1, usersOrderList[i][j]);
            }
        }
    }

    if (!ordersExist)
    {
        printf("No orders have been placed yet.\n");
    }

    printf("============================================================\n");
    printf("Press any key to return to admin menu...");
    getch();
    system("cls");
    isAdmin(user, password);
}

void validationsignin()
{
    system("cls");
    printf("=====================\n");
    printf("      SIGN IN\n");
    printf("=====================\n");
    printf("Enter your username: ");
    scanf(" %[^\n]s", user);
    printf("Enter your password: ");
    scanf(" %[^\n]s", password);

    signIn(user, password);
}
void inventory()
{
    int opt;
    do
    {
        system("cls");
        printf("====================================\n");
        printf("      INVENTORY MANAGEMENT\n");
        printf("====================================\n");
        printf("1. View All Items\n");
        printf("2. Add New Items\n");
        printf("3. Delete Items\n");
        printf("4. Exit\n");
        printf("-------------------------------------------------------------\n");
        printf("Enter your choice: ");
        scanf("%d", &opt);

        switch (opt)
        {
        case 1:
            system("cls");
            viewitems();
            break;
        case 2:
            system("cls");
            additems();
            break;
        case 3:
            system("cls");
            delitems();
            break;
        case 4:
            printf("Exiting....\n");
            getch();
            system("cls");
            isAdmin(user, password);
            return;
        default:
            printf("Invalid Choice\n");
            getch();
            break;
        }
    } while (1);
}

void viewitems()
{
    printf("====================================\n");
    printf("        TOTAL MENU ITEMS\n");
    printf("====================================\n");
    for (int i = 0; i < totalMenuItems; i++)
    {
        printf("%d. %s - $%.2f (Stock: %d)\n", i + 1, menuItems[i], itemPrices[i], stockQuantities[i]);
    }
    printf("Press any key to continue...");
    getch();
}

void additems()
{
    char item[50];
    double price;
    int quantity;

    printf("Enter the name of item: ");
    scanf(" %[^\n]s", item);
    printf("Enter the price: ");
    scanf("%lf", &price);
    printf("Enter the stock quantity: ");
    scanf("%d", &quantity);

    strcpy(menuItems[totalMenuItems], item);
    itemPrices[totalMenuItems] = price;
    stockQuantities[totalMenuItems] = quantity;
    totalMenuItems++;

    printf("====================================\n");
    printf("Item added successfully!\n");
    saveMenuToFile();
    printf("====================================\n");
    printf("Press any key to continue...");
    getch();
}

void delitems()
{
    int index;
    printf("====================================\n");
    printf("        TOTAL MENU ITEMS\n");
    printf("====================================\n");
    for (int i = 0; i < totalMenuItems; i++)
    {
        printf("%d. %s\n", i + 1, menuItems[i]);
    }

    do
    {
        printf("\nEnter the index of item you want to delete (1-%d): ", totalMenuItems);
        scanf("%d", &index);
        if (index < 1 || index > totalMenuItems)
        {
            printf("Invalid index. Please try again.\n");
        }
    } while (index < 1 || index > totalMenuItems);

    for (int i = index - 1; i < totalMenuItems - 1; i++)
    {
        strcpy(menuItems[i], menuItems[i + 1]);
        itemPrices[i] = itemPrices[i + 1];
        stockQuantities[i] = stockQuantities[i + 1];
    }
    totalMenuItems--;

    printf("====================================\n");
    printf("        UPDATED MENU ITEMS\n");
    printf("====================================\n");
    for (int i = 0; i < totalMenuItems; i++)
    {
        printf("%d. %s\n", i + 1, menuItems[i]);
    }
    printf("\nThe remaining number of items: %d\n", totalMenuItems);
    saveMenuToFile();
    printf("Press any key to continue...");
    getch();
}

void orders()
{
    int index, quantity;
    char opt;
    char orderDetails[100];
    totalBill = 0;

    do
    {
        system("cls");
        printf("====================================\n");
        printf("            MENU\n");
        printf("====================================\n");
        for (int i = 0; i < totalMenuItems; i++)
        {
            printf("%d. %s - $%.2f\n", i + 1, menuItems[i], itemPrices[i]);
        }

        printf("\nEnter item number: ");
        scanf("%d", &index);

        if (index < 1 || index > totalMenuItems)
        {
            printf("Invalid item choice!\n");
            getch();
            continue;
        }

        printf("Enter quantity: ");
        scanf("%d", &quantity);

        // Format: Item (Quantity: X, Price: $Y)
        sprintf(orderDetails, "%s (Quantity: %d, Price: $%.2f)",
                menuItems[index - 1], quantity, itemPrices[index - 1] * quantity);

        strcpy(usersOrderList[currentUserIndex][userOrderCounts[currentUserIndex]], orderDetails);
        userOrderCounts[currentUserIndex]++;
        totalOrders++;

        printf("Order placed!\n");
        printf("Do you want to order anything else? (y/n): ");
        scanf(" %c", &opt);

    } while (opt == 'y' || opt == 'Y');
    printReceipt();
}
void printReceipt()
{
    int code;
    double total = 0, pay;
    char line[100];
    system("cls");

    printf("\n====================================\n");
    printf("            RECEIPT\n");
    printf("====================================\n");
    printf("Customer: %s\n", users[currentUserIndex]);
    printf("-------------------------------------------------------------\n");

    for (int i = 0; i < userOrderCounts[currentUserIndex]; i++)
    {
        printf("%s\n", usersOrderList[currentUserIndex][i]);

        // Extract price after '$'
        char *dollarSign = strchr(usersOrderList[currentUserIndex][i], '$');
        if (dollarSign != NULL)
        {
            double itemPrice = atof(dollarSign + 1);
            total += itemPrice;
        }
    }

    printf("-------------------------------------------------------------\n");
    printf("Total Amount: $%.2f\n", total);
    printf("====================================\n");

    printf("Dine-in or Takeaway? ");
    scanf(" %[^\n]s", preferance);

    printf("Do you have discount coupon (y/n): ");
    scanf(" %[^\n]s", yesno);

    if (strcmp(yesno, "y") == 0 || strcmp(yesno, "Y") == 0)
    {
        printf("Enter the code of discount: ");
        scanf("%d", &code);
        if (code == 1234)
        {
            printf("====================================\n");
            printf("            PAYMENT\n");
            printf("====================================\n");
            printf("Your total bill is: $%.2f\n", total);
            printf("After discount your total bill is: $%.2f\n", total - (total * discountvalue));
            total = total - (total * discountvalue);
        }
        else
        {
            printf("====================================\n");
            printf("            PAYMENT\n");
            printf("====================================\n");
            printf("Your total bill is: $%.2f\n", total);
        }
    }
    else
    {
        printf("====================================\n");
        printf("            PAYMENT\n");
        printf("====================================\n");
        printf("Your total bill is: $%.2f\n", total);
    }

    while (1)
    {
        printf("Enter cash: $");
        scanf("%lf", &pay);

        if (pay > total)
        {
            printf("Your change: $%.2f\n", pay - total);
            printf("Thank you!\n");
            getch();
            break;
        }
        else if (pay < total)
        {
            total = total - pay;
            printf("Remaining amount: $%.2f\n", total);
            printf("Please pay the remaining amount...\n");
            getch();
        }
        else
        {
            printf("Thank you!\n");
            getch();
            break;
        }
    }

    saveOrdersToFile();
    totalBill = 0;
    system("cls");
}

void discount()
{
    printf("====================================\n");
    printf("Change the discount value in percentage (as decimal): ");
    scanf("%lf", &discountvalue);

    isAdmin(user, password);
}
